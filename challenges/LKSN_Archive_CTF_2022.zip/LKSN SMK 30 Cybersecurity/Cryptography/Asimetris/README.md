# Asimetris [300 pts]

**Category:** Cryptography
**Solves:** 0

## Description
>Rivest-Shamir-Adleman adalah sesuatu yang cukup spesial di dalam dunia kriptografi.\r\nYuk kita belajar bersama!\r\n\r\nSetelah flagnya telah dienkripsi dengan menggunakan algoritma enkripsi tersebut, bisakah kalian merecover flagnya?

**Hint**
* -

## Solution

### Flag

