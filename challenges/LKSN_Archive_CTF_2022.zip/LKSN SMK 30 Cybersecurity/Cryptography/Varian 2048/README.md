# Varian 2048 [500 pts]

**Category:** Cryptography
**Solves:** 0

## Description
>Saya pikir implementasi "Asimetris" yang satu ini lebih aman dibanding sebelumnya!\r\nSaya pastikan angka primanya cukup kuat dengan size 2048 bit, dan saya enkripsi sebanyak tiga kali sehingga teman-teman pasti akan merasa kesulitan untuk merecovernya hehe ~\r\n\r\nOleh karena itu, bagaimana jika saya berikan teman-teman sebuah harapan dengan memberikan banyak encrypted messagenya beserta dengan modulusnya ^-^ ?\r\n\r\nBisakah Anda me-recover flagnya kembali?

**Hint**
* -

## Solution

### Flag

