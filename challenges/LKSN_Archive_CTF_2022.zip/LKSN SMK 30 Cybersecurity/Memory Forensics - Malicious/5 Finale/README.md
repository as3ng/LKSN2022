# 5 Finale [199 pts]

**Category:** Memory Forensics - Malicious
**Solves:** 2

## Description
>**Bagian Kelima**\r\n\r\nDapat diasumsikan bahwa teman Anda melakukan aktivitas *malicious* untuk menanamkan suatu program berbahaya di dalam komputer teman Anda yang lainnya. Meski aksinya tidak berhasil dijalankan 100% karena objektifnya yang tidak terpenuhi, ternyata program ini memiliki kapabilitas untuk merekam jejak ketikan input seorang *user*.\r\n\r\nBerikut merupakan ekstraksi *encrypted* file yang didapatkan dari komputer korban ketika ia sedang diawasi oleh temannya (si jahat) sesaat setelah dia menanamkan programnya. Dapatkah kamu mendekrip *encrypted* file tersebut?\r\n\r\nUntuk melakukan dekrip, tentunya Anda harus melakukan reverse engineering terhadap program malware yang sudah Anda dapatkan dari VMEM-nya.\r\n\r\nFlag = hasil konten dekripsi mengandung flag `LKSN{.*}`, submit konten flagnya

**Hint**
* -

## Solution

### Flag

