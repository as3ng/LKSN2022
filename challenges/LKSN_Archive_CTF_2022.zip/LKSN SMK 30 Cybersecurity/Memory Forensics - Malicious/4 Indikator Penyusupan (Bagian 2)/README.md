# 4 Indikator Penyusupan (Bagian 2) [191 pts]

**Category:** Memory Forensics - Malicious
**Solves:** 4

## Description
>**Bagian Keempat**\r\n\r\nSetelah menganalisa secara statik dari program tersebut, saatnya beralih ke metodologi analisa IOC lebih dalam. Anda diminta untuk mengumpulkan data berikut:\r\n\r\na) Nilai Entropi dari Program (Ambil pembulatan 2 angka di belakang koma, misalkan didapat nilai 3.148927 maka nilainya 3.15 namun jika nilainya 3.14321 maka nilainya 3.14 )\r\n\r\nb) Jumlah *sections* pada Program\r\n\r\nHasil jawaban digabung dengan delimiter *underscore*.\r\n\r\nMisalkan yang Anda temukan untuk nilai entropinya adalah 4.57297 dan jumlah sectionsnya ada 20, maka flagnya adalah **4.57_20**

**Hint**
* -

## Solution

### Flag

