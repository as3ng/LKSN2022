# 1 Shoulder Surfing [136 pts]

**Category:** Memory Forensics - Malicious
**Solves:** 9

## Description
>Semua Link file berlaku untuk semua challenge Memory Forensics. \r\nSilahkan akses dan download file di link ini:\r\nhttps://drive.google.com/file/d/1ILdsJSYTKRiFXO6yOd_wlSzptuCu9es3/view?usp=sharing\r\n\r\n**Password: saya_bUkan_8j0rka_tapi_g3n3rasi_emas_b4ngs4_Ind0nesia**\r\n\r\nSemua bagian soal kategori ini merupakan seri challenge "Malicious"\r\n\r\n**Bagian Pertama**\r\n\r\nAnda telah mendapati teman sekantor Anda tengah melakukan sesuatu yang cukup "malicious" pada victim host computer teman Anda dari CCTV. Sebelumnya, dia sedang melakukan shoulder surfing terhadap victim dan tim forensik mengira jika dia ingin mengingat kombinasi password temannya. Tatkala dikira itu sangatlah tidak mungkin, ternyata dia dapat mengakses komputernya dengan mudah. Beberapa menit kemudian, teman sekantor Anda tertangkap basah dan melarikan diri.\r\n\r\nDapatkah Anda mendapatkan **password logon OS** yang memang telah "diingat" oleh si penyerang? Tim Digital Forensik telah melakukan akuisisi memori pada laptop korban dan mereka meminta Anda untuk  mengetes jika password tersebut bahkan **sangat mudah untuk didapatkan**.\r\n\r\nFormat: passwordnya

**Hint**
* -

## Solution

### Flag

