# 2 Awal Mula [100 pts]

**Category:** Memory Forensics - Malicious
**Solves:** 11

## Description
>**Bagian Kedua**\r\n\r\nTim Digital Forensik melanjutkan investigasi dari apa yang dilakukan oleh penyerang di dalam komputer teman Anda, namun karena tim ini sedang sibuk mengurusi event LKSN 2022, dapatkah Anda membantu mereka untuk menemukan proses apa yang menurut Anda sedang berjalan dan cukup malicious? Anda cukup mencantumkan *Process ID*  -nya saja disini sebagai flagnya.

**Hint**
* -

## Solution

### Flag

