# VM 2 [1337 pts]

**Category:** Patching
**Solves:** 19

## Description
>https://drive.google.com/drive/folders/1I418msCxm6vLq414z4U85AygAePkt39j?usp=sharing\r\n\r\nPassword Zip: 4b023086b50ef3e1a89f495c262cab50\r\n\r\nCredential root\r\n\r\nUsername : root\r\n\r\nPassword : PASSrot1313\r\n\r\nCredential Low-Privilege\r\n\r\nfelix:FelixG0d47593\r\n\t\r\nstanley:PKSDJWIQWE@Mantap\r\n\r\nSaran menggunakan ssh agar memudahkan patching ( tidak bisa root )\r\n\r\nssh {username}@{IP}\r\n\r\nFile ini **SAMA DENGAN** file VM 2 di Day 2 kemarin.\r\n\r\nAnda diminta untuk melakukan ***vulnerability patching*** terhadap *instance* OVA ini sekaligus juga melakukan **infrastructure hardening**. Segala bentuk vulnerability yang ada di dalamnya **TIDAK BOLEH** Anda hilangkan atau hapus, tetapi Anda patch dan modifikasi supaya jauh lebih aman.\r\n\r\nContohnya, jika terdapat indikasi adanya penyimpanan suatu password data pada suatu medium kriptografi atau semacamnya, Anda dapat memodifikasi algoritmanya menjadi lebih aman. Jika ada suatu *pblic services* yang terekspos ke publik dengan *credentials* yang cukup lemah dan *predictable*, Anda dapat mengubah konfigurasinya, dan metodologi *patching* lainnya.\r\n\r\nPenilaian soal VM Patching (*Infrastructure Hardening*) ini akan dilihat pada laporan PDF yang akan Anda buat setelah Day 3 selesai dan dikumpulkan pada Google Form yang dikirimkan setelah Day 3 selesai (di Whatsapp Group).\r\n\r\nJika ada pertanyaan mengenai VM Patching, Anda dapat menghubungi Bapak Chrisando atau Stanley Halim di Whatsapp ataupun langsung di Zoom.\r\n\r\nHappy Securing!\r\n\r\n**Free flag submit challenge ini:\r\nLKSN{VM_P4tcH1ng}**

**Hint**
* -

## Solution

### Flag

