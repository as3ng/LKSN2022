# Network Security Design [0 pts]

**Category:** Conceptual Examination
**Solves:** 0

## Description
>Selamat datang di Hari Pertama LKSN SMK XXX Cyber Security.\r\nBatas pengumpulan laporan / POC adalah pada tanggal 25 Oktober 2022, pukul 20.00 WIB.\r\n\r\nLaporan dikumpulkan ke: https://forms.gle/yF2jY7XPzWnV4AkV9\r\n\r\nHappy Securing!

**Hint**
* -

## Solution

### Flag

