# 2 Sumber Kenakalan [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 14

## Description
>**Bagian Kedua**\r\n\r\nPihak kepolisian menerka sumber kenakalan remaja Bobby berasal dari kecanduan aplikasi ataupun dari lingkungan pertemanannya. Laman URL apa yang dikunjungi oleh Bobby yang **pertama kali**-nya selain **Google** ?\r\n\r\nFormat:   http://inihanyasebatascontohsajaya.com

**Hint**
* -

## Solution

### Flag

