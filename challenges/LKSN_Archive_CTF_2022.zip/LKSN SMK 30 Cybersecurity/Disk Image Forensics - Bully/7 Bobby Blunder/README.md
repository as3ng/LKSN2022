# 7 Bobby Blunder [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 12

## Description
>**Bagian Ketujuh**\r\n\r\nKarena masih anak SMA, ternyata Bobby juga bisa saja teledor menyimpan sesuatu yang sifatnya rahasia dan gampang terekspos oleh publik karena pihak Anda berhasil mendapatkan sesuatu dari sana.\r\nBobby telah menyimpan sebuah **backup password** yang ada pada aplikasi *note-taking* yang sama dengan sebelumnya. Apakah **isi konten** dari backup passwordnya?\r\n\r\nFormat:   hUrUf@lay

**Hint**
* -

## Solution

### Flag

