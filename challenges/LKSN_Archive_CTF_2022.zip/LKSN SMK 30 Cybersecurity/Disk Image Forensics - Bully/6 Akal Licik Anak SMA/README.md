# 6 Akal Licik Anak SMA [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 12

## Description
>**Bagian Keenam**\r\n\r\nBobby telah tertangkap basah oleh Anda karena Anda mengetahui bahwa dia telah menyusun rencana usilnya yang masih dalam aplikasi *note-taking*-nya.\r\nSiapakah nama dari **korban pertama** rencana jahatnya? (**huruf kecil semua tanpa spasi**)\r\n\r\nFormat: namabiasa

**Hint**
* -

## Solution

### Flag

