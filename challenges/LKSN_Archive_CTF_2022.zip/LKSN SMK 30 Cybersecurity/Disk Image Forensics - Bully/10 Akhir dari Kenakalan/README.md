# 10 Akhir dari Kenakalan [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 3

## Description
>**Bagian Kesepuluh**\r\n\r\nBobby akhirnya diketahui telah melakukan tindakan aksi yang sangat meresahkan sehingga membuat ia harus ditahan dulu oleh polisi karena bukti Anda.\r\nDia terdakwa telah **menjual senjata** dengan bukti yang didapatkan **di aplikasi *note-taking* LAIN MESKIPUN notes tersebut telah DIHAPUS**. Dapatkah Anda menyebutkan 2 senjata tajam yang ia jual sebagai supplier?\r\n\r\nAnda juga dapat mengganti jawaban ini jika Anda berhasil menemukan sebuah gambar di dalam notes tersebut. Terdapat tulisan kecil di dalamnya, dan tulisan itu juga dapat menjadi jawaban valid bagi soal ini sebagai **flag** yang valid. \r\n\r\nSehingga, Anda diberikan harapan bahwa ada 2 Flag pada soal ini (bebas yang manapun itu benar).\r\n\r\nFormat Flag 1:\r\nJika Anda berhasil menemukan 2 nama senjatanya yaitu pisau belati dan golok, maka flagnya adalah **pisaubelatigolok**.\r\n\r\nFormat Flag 2 (alternatif):\r\nJika Anda mendapatkan kata-kata pada logo merahnya yakni setanmerah123 asiap, maka flagnya adalah **setanmerah123asiap**. \r\n\r\nSemua jawabannya dalam huruf kecil **TANPA **spasi.

**Hint**
* -

## Solution

### Flag

