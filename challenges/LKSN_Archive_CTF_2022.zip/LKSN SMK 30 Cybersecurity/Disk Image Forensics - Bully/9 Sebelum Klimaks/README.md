# 9 Sebelum Klimaks [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 3

## Description
>**Bagian Kesembilan**\r\n\r\nBobby juga ternyata didapati bahwa ada **rencana jahat lainnya** yang ada pada **aplikasi note-taking yang sama** dengan sebelumnya NAMUN notes yang berisikan rencana jahat itu telah **DIHAPUS**. Anda sebagai tim Forensik tentunya tahu bahwa segala file yang dihapus pasti masih bisa dapat direcover dan dicek kembali apapun itu bukti digitalnya. \r\nApa nama **judul** dari Notes yang telah ia hapus tersebut?\r\n\r\nFormat: judulnotestanpaspasi

**Hint**
* -

## Solution

### Flag

