# 8 Detil Rencana [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 5

## Description
>**Bagian Kedelapan**\r\n\r\nBobby merasa ketakutan karena kemampuan forensik Anda sangatlah handal. Anda ingin mengecek kapan **terakhir kali** Bobby **meng-*update* rencana jahatnya pada notes** yang telah dia buat **sebelumnya**. Apakah Anda dapat mengetahuinya?\r\n\r\nFormat jawaban (DD/MM/YYYY jam:menit WIB)\r\n\r\nContoh: 08/01/2007 12:37 WIB

**Hint**
* -

## Solution

### Flag

