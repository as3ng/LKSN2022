# 3 Mencari Tahu [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 9

## Description
>**Bagian Ketiga**\r\n\r\nAnda dan pihak Digital Forensik lainnya sedang menganalisa secara detil dari Android Image milik HP Bobby hingga ke akar-akarnya Anda mencurigai sebuah laman yang padahal tidak berbahaya.\r\nApa nilai **Cookie** yang ada ketika ia mengunjungi sebuah laman website dengan domain **account.kompas.com**?\r\n\r\nFormat: `inivaluecookieYangAndaTemukanJanganSubmitInihey8109109902902++_)_)_)`

**Hint**
* -

## Solution

### Flag

