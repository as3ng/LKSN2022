# 1 Ketagihan [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 16

## Description
>Laman file: https://drive.google.com/file/d/1RQ-lT-yW-iCTPqgx8EfVOfLGfNIQHU3X/view?usp=sharing\r\n\r\nPassword file: **peserta_LKSN_terlalu_GG_dan_OP_2k22!**\r\n\r\n**Bagian Pertama**\r\n\r\nAwal Deskripsi Kasus:\r\n\r\nBobby, merupakan seorang anak SMA yang sangat nakal. Ia pernah masuk ke dalam penjara remaja sejak SMP karena kelakuannya yang suka menjahili temannya hingga berlebihan. Kini, Bobby berulah lagi hingga membuat banyak temannya merasa kesal dengannya hingga dipanggil polisi daerah. Bobby gemar menutupi jejak aksinya dan sangat terencana, oleh karena itu polisi daerah diberikan penugasan untuk mengecek HP Bobby jika ada keanehan atau kekeliruan di dalamnya. Anda, sebagai tim Digital Forensik yang dapat diandalkan diminta untuk melakukan analisa dari hasil akuisisi sebuah **Android Image Phone**. \r\n\r\nPertanyaan:\r\n\r\nApa nama aplikasi *browser* yang digunakan oleh tersangka? (nama *Android Package Name* )\r\n\r\nFormat:   com.apapunini.mbahgugel

**Hint**
* -

## Solution

### Flag

