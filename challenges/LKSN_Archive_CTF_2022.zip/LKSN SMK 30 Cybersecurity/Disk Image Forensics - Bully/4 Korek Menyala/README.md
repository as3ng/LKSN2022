# 4 Korek Menyala [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 12

## Description
>**Bagian Keempat**\r\n\r\nAnda mengecek jika laman pencarian teratas yang dicari Bobby pada *browser*-nya mengindikasikan perilaku sosiopat. Apakah hasil pencarian **teratas** saat Bobby sedang menggunakan ***search bar browser*** -nya?\r\n\r\nFormat: ini hasil pencariannya guys pakai spasi

**Hint**
* -

## Solution

### Flag

