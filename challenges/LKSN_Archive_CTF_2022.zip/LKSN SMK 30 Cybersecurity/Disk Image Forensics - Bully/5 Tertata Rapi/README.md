# 5 Tertata Rapi [100 pts]

**Category:** Disk Image Forensics - Bully
**Solves:** 15

## Description
>**Bagian Kelima**\r\n\r\nBobby ternyata menyimpan rencananya pada sebuah aplikasi *note-taking* khusus.\r\nApa nama aplikasi yang digunakan penyerang untuk melakukan *note taking*? (nama *package name* Android-nya)\r\n\r\nFormat: com.lksn.menangsemua

**Hint**
* -

## Solution

### Flag

