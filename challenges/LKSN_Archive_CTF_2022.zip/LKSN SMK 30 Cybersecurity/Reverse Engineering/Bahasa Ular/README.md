# Bahasa Ular [200 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Selamat datang di challenge reversing pertama!\r\nYuk kita pahami bersama bahasa "ular" ini ~\r\nBahasa ini sangat umum digunakan untuk melakukan `scripting` lho!\r\nDapatkah kamu me-recover hasil orisinil dari flag.txt yang sudah terenkripsi? :(

**Hint**
* -

## Solution

### Flag

