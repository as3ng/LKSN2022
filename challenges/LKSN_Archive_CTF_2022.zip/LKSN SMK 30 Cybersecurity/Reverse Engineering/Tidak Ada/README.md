# Tidak Ada [300 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Selamat datang di challenge reversing kedua!\r\nSudahkah Anda belajar Reverse Engineering dengan baik? Yuk coba tebak input apa yang benar pada program ini?

**Hint**
* -

## Solution

### Flag

