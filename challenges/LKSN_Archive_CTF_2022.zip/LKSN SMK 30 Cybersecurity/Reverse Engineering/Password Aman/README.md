# Password Aman [500 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Selamat datang di challenge reversing terakhir!\r\nTakumi ingin membuat sebuah program yang dapat memvalidasi input user kembali namun sekarang jauh lebih aman!\r\nBagaimana jika kamu *crack* program yang satu ini?

**Hint**
* -

## Solution

### Flag

